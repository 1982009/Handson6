
const Product = () => {
  return (
    <div>Product Page</div>
  )
}

export default Product