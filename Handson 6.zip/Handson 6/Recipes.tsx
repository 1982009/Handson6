
const Recipes = () => {
  return (
    <div>Recipes Page</div>
  )
}

export default Recipes